import React, {Component} from 'react';

export default class FB extends Component {
 render(){
     return(

         <div className="fb-follow" data-href="https://www.facebook.com/pg/&#x41a;&#x430;&#x444;&#x435;&#x434;&#x440;&#x430;-&#x41f;&#x406;&#x421;-1834681390130372/posts/?ref=page_internal" data-layout="box_count" data-size="large" data-show-faces="true"></div>

     )
 }
}
